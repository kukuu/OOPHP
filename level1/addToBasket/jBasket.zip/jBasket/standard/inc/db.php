<?php
$dbhost							= "localhost";
$dbuser							= "";
$dbpass							= "";
$dbname							= "";

$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die ("Error connecting to mysql");
mysql_select_db($dbname);
?>