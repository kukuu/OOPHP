[
    {
        "category": "Women",
        "subcat": "Clothing",
        "item": "Party wear - Front Leather Panelled Ponte Treggings",
        "price": "159.00",
        "uid": 1
    },
    {
        "category": "Women",
        "subcat": "Clothing",
        "item": "Speziale Italian Cupro Draped Bodycon Dress",
        "price": "89.00",
        "uid": 2
    },
    {
        "category": "Beauty",
        "subcat": "Skincare",
        "item": "Aptiva - Wine Elixir Night Cream",
        "price": "79.00",
        "uid": 3
    },
    {
        "category": "Men",
        "subcat": "Suits & Tailoring",
        "item": "Sartorial – Slim Fit Luxury Pure Cotton Rib Striped Shirt",
        "price": "39.50",
        "uid": 4
    },
    {
        "category": "Men",
        "subcat": "Jeans",
        "item": "Big & Tall Washed Look Bootleg Denim Jeanst",
        "price": "25.00",
        "uid": 5
    },
    {
        "category": "Men",
        "subcat": "Jeans",
        "item": "Tapered Jeans with Comfort Stretch",
        "price": "22.50",
        "uid": 6
    },
    {
        "category": "Kids",
        "subcat": "Toys & Games",
        "item": "Boys Stuff - Top Secret",
        "price": "5.00",
        "uid": 7
    },
    {
        "category": "Food & Wine",
        "subcat": "Wines, Beers & Spirit",
        "item": "Exclusive to Order - Arriero Carmenere (case of 6)",
        "price": "53.94",
        "uid": 8
    },
    {
        "category": "Flowers & Gifts",
        "subcat": "Flowers & Hampers",
        "item": "New Baby - Dog Comfort Toy",
        "uid": 9
    },
    {
        "category": "Flowers & Gifts",
        "subcat": "Gifts Bags",
        "item": "Rose & Freesia Gift Bag",
        "uid": 10
    }
]