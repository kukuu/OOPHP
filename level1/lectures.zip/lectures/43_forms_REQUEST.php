
<html>
<head>
	<title>Using PHP Forms</title>
</head>
<body>
	 <?php echo "Welcome ". $_REQUEST["fname"]."!<br />"; ?>
	 <?php echo "You are ".$_REQUEST["age"]. " years old"; ?> .
</body>
</html>
