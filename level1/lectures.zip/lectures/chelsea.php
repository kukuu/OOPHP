<?php 
echo "This is the  $premierClub squad for the European Champions League<br />";
echo "
1   Petr Cech <br />
2   Branislav Ivanovic <br />
3   Ashley Cole <br />
5   Michael Essien <br />
7   Ramires <br />
8   Frank Lampard <br />
10   Yossi Benayoun <br />
11   Didier Drogba <br />
12   Mikel <br />
15   Florent Malouda <br />
17   Jose Bosingwa <br />
18   Yuri Zhirkov <br />
19   Paulo Ferreira <br />
20   Deco <br />
21   Salomon Kalou <br />
22   Ross Turnbull <br />
23   Daniel Sturridge <br />
26   John Terry <br />
33   Alex <br />
38   Patrick Van Aanholt <br />
39   Nicolas Anelka <br />
40   Henrique Hilario <br />
41   Sam Hutchinson <br />
43   Jeffrey Bruma <br />
44   Gael Kakuta <br />
45   Fabio Borini <br />
50   Jacob Mellis <br />
50   Jan Sebeck <br />";
?>