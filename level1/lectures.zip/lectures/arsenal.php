<?php
	echo "This is the  $premierClub squad for the European Champions League<br />";
	echo "1   Manuel Almunia<br />
2   Vassiriki Diaby <br />
3   Bacary Sagna <br />
4   Francesc Fabregas <br />
5   Thomas Vermaelen <br />
6   Laurent Koscielny<br /> 
7   Tomas Rosicky<br /> 
8   Samir Nasri <br />
10   Robin van Persie<br /> 
11   Carlos Alberto Vela <br />
14   Theo Walcott<br /> 
15   Neves Denilson<br /> 
16   Aaron Ramsey <br />
17   Alex Song <br />
19   Jack Wilshere <br />
20   Johan Djourou <br />
21   Lukasz Fabianski <br />
22   Gael Clichy <br />
23   Andrey Arshavin <br />
24   Vito Mannone <br />
27   Emmanuel Eboue <br />
28   Kieran Gibbs <br />
29   Marouane Chamakh <br />
31   Jay Emmanuel-Thomas <br />
33   Mark Randall <br />
34   Havard Nordtveit <br />
35   Emmanuel Frimpong <br />
36   Gavin Hoyte <br />
36   Thomas Cruise <br />
37   Craig Eastmond <br />
37   Nico Yennaris <br />
44   Rhys Murphy <br />
49   James Shea <br />
51   Gilles Sunu <br />
52   Nicklas Bendtner <br /> 
53   Wojciech Szczesny <br />
  	 Sebastien Squillaci ";
?>
