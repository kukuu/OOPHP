<?php
	class dog {
		function eat_snake() {
			echo "The dog ate the snake";
		}
	}
?>