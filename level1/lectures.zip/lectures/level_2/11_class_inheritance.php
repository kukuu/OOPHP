// 'extends' is the keyword that enables inheritance. Here 'employee' is a type of 'person'.
class employee extends person {
	function __construct($employee_name) {
		$this->set_name($employee_name);

	}
}

