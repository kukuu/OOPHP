<?php

class Dog {
	public function eat_snake()
	{
		echo "The dog ate the snake";
	}
	
	public function eat_ants()
	{
		echo "The dog ate the ants";
	}
}
