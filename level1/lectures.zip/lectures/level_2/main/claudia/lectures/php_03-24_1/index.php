 <html>
 <head>
	<title>Using PHP forms</title>
 </head>
 <body>
	<?php echo "Welcome " . $_REQUEST['fname'] . "!<br>";?>
	<?php echo "You are " . $_REQUEST['age'] . "!<br>";?>
 </body>
 </html>