 <html>
 <head>
 </head>
 <body>
	<form action="index.php" method="post">
		Name: <input type="text" name="fname"><br />
		Age: <input type="text" name="age"><br />
		<input type="submit">
	</form>
 </body>
 </html>