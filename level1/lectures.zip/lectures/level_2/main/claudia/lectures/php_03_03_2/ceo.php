<?php
include ('executive.php');
/*
* Extending Executive: class CEO extends executive
*/
class CEO extends Executive {
	public function getFaceLift()
	{
		echo " I need some square jaws";
	}
}

?>