<?php 

$c1= new Customer("Alexander","Morgan","The Anatolian Shepherd Dog is very, very loyal and possessive of his home and family. He tends to bark at night to warn predators away unless he is inside. The Anatolian Shepherd can be a very fierce fighter if he needs to be.",1);

$c2= new Customer("James","Ballantyne","The Belgian Shepherd (also known as the Belgian Sheepdog or Chien de Berger Belge) is a breed of medium-to-large-sized herding dog. It originated in Belgium and is similar to other sheep herding dogs from that region, including the Dutch Shepherd Dog, the German Shepherd Dog, the Briard and others.",2);

?>