<html>
<head>
	<title>Using PHP Forms</title>
</head>
<body>
	Welcome <?php echo $_POST["fname"]; ?><br />
	You are <?php echo $_POST["age"]; ?> years old.
</body>
</html>


