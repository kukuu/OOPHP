<?php
    print 'This string will $print exactly as it\'s  \n declared (because it uses single quotes as delimeters or boundaries)';
?> 
