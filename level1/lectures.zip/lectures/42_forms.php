
<html>
<body>
<form action="43_forms_REQUEST.php" method="post">
	Name: <input type="text" name="fname" /><br />
	Age: <input type="text" name="age" /><br />
	<input type="submit" />
</form>
</body>
</html>


