
<html>
<head>
	<title>Using PHP Forms</title>
</head>
<body>
<form action="41_formsGET.php" method="get">
	Name: <input type="text" name="fname" /><br /><br />
	Age: &nbsp;&nbsp;&nbsp;<input type="text" name="age" /><br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" />
</form>
</body>
</html>


