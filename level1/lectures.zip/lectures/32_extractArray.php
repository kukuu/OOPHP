<?php
	$shirtinfo = array ("size" =>"large", "colour" => "blue" ,"cost" => "12.00");
	extract($shirtinfo);
	echo "size is $size,<br /> colour is $colour, <br />cost is $cost ";
?>



