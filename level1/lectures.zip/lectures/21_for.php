<?php
	/*used as a counter to determine how many times an action will be processed as well as relinquish execution*/
			for($i=1;$i<=3;$i++) {
				echo "$i. Hello PHP World <br />";
			}
		?>
