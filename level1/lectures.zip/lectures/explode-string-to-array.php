<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>array and strng conversions</title>
</head>

<body>
<?php
	$s1 = 'Mon-Tue-Wed-Thurs-Fri';
	$days_array =  explode('-',$s1);
	echo $days_array;
?>
	


</body>
</html>
