<?php
//multiply a value by 10 and return to the caller
	function x10($value) {
		$finalAnswer = $value  * 10;
		return $finalAnswer;
	}
	echo x10(20);
	
?>
