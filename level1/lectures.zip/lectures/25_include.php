

<?php
	include_once('./xinclude.php');//includes it only once
	require_once('./xrequire.php');
?>

