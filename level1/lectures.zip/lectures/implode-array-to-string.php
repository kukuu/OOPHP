<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>array and strng conversions</title>
</head>

<body>
<?php
    $days_array = 'Mon-Tue-Wed-Thurs-Fri';
	$s2 =  implode(', ', $days_array);
	echo $s2;
?>
	


</body>
</html>
