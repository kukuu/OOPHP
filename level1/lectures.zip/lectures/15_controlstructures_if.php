<?php 

	$secretNumber = 045;
	if($_POST['guess'] == $secretNumber) {
		echo "<p>Congratulations!</p>";
	}

?>
