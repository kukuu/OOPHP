<?php
//The counter here has been used to display just 4 out of the six names
$customerName = array ("grace","doris","gary","nate","tim","tom");
			for($i=0;$i<4;$i++) {
				echo "$customerName[$i] <br />";
			}
		?>

