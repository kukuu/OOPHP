//As a simple example we will unit test 
//an app that has a single screen to add two 
//numbers and display the result upon a button click 