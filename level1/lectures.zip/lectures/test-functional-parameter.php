<?php 

	function sayHello($name){
		$visitor = $name." welcome to our club";
		return $visitor;
	}
	echo sayHello("Alex");

?>