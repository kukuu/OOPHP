<?php
	$count = 1;
	while ($count <5) {
	printf("%d cubed = %d <br />",$count, pow($count,3)); 
	$count++;
}

?>
