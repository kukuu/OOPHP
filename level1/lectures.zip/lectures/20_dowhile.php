<?php
	$count = 11;
	do {
		printf ("%d squared = %d <br />",$count ,pow($count,2));
	 }while($count < 10);

?>

