<?php
	/*encapsulating string in double quotes guarantees both the parsing of variables and escape sequence*/
    $output = "This is one line. \n And this is another line";
    echo  $output ;
?>

