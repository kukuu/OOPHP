<?php
    $sport = "cricket";
    echo "Mike's favourite sport is <strong>$sport</strong>";
?>
