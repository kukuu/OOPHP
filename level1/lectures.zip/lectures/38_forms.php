<html>
<head>
	<title>Using PHP Forms</title>
</head>
<body>
<form action="39_forms_welcome.php" method="post">
	Name: <input type="text" name="fname" /><br /><br />
	Age: &nbsp;&nbsp;&nbsp;<input type="text" name="age" /><br /><br />
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" />
</form>
</body>
</html>


