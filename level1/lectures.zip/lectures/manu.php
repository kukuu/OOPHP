<?php 
echo "This is the  $premierClub squad for the European Champions League<br />";
echo "1   Edwin Van der Sar <br />
2   Gary Neville <br />
3   Patrice Evra <br />
4   Owen Hargreaves <br />
5   Rio Ferdinand <br />
6   Wes Brown <br />
7   Michael Owen<br />
8   Oliveira Anderson <br />
9   Dimitar Berbatov <br />
10   Wayne Rooney <br />
11   Ryan Giggs <br />
12   Chris Smalling <br />
13   Ji-Sung Park <br />
14   Javier Hernandez <br />
15   Nemanja Vidic <br />
16   Michael Carrick <br />
17   Luis Nani <br />
18   Paul Scholes <br />
20   Fabio Da Silva <br />
21   Rafael Da Silva <br />
22   John O'Shea <br />
23   Jonathan Evans <br />
24   Darren Fletcher <br />
25   Antonio Valencia <br />
26   Gabriel Obertan <br />
27   Federico Macheda <br />
28   Darron Gibson <br />
29   Tomasz Kuszczak <br />
30   Ritchie De Laet <br />
31   Corry Evans <br />
40   Ben Amos <br />
42   Magnus Eikrem <br />"
?>