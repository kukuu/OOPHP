
<?php
echo '<br /><img src="/lectures/images/teddy.gif"><br /><span class=torquoise>Bye now </span><br /> <span class=torquoise><strong>Alex</strong></span>!';
?>



