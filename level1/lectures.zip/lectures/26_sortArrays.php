<?php
	$capitals= array ("Paris","London","New York");
	sort($capitals);
	for($i=0;$i<count($capitals);$i++) {
	echo "$capitals[$i] <br />";	
	//sizeof function  would perform the same operation as count function
}
	

?>
