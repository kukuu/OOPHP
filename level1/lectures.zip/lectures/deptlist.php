<!--From: <Saved by Windows Internet Explorer 7>
Subject: Members Only
Date: Thu, 10 Jul 2008 08:41:24 +0100
MIME-Version: 1.0
Content-Type: text/html;
	charset="Windows-1252"
Content-Transfer-Encoding: quoted-printable
Content-Location: http://localhost/lectures/department.php?query=select+*+from+deptlist%3B
X-MimeOLE: Produced By Microsoft MimeOLE V6.00.2900.3198-->

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- Program Name:  mysql_send.php
     Description: PHP program that sends an SQL query to the
                  MySQL server and displays the results.
-->

<HTML><HEAD><TITLE>Members Only</TITLE>
<META http-equiv=3DContent-Type content=3D"text/html; =
charset=3Dwindows-1252">
<STYLE>.red {
	COLOR: #ff0000
}
.gold {
	FONT-SIZE: 2em; COLOR: #ff9933
}
.torquoise {
	FONT-WEIGHT: bold; COLOR: #ff00ff
}
.dg {
	COLOR: #ffcc33
}
</STYLE>

<META content=3D"MSHTML 6.00.6000.16674" name=3DGENERATOR>
</HEAD>
<BODY>


<H4 align=3Dcenter>select * from deptlist;</H4>
<TABLE width=3D650 align=3Dcenter bgColor=3D#ffcc33 border=3D2 noshade>
  <TBODY>
  <TR>
    <TH bgColor=3D#808080>Department Number</TH>
    <TH bgColor=3D#cccccc>Department Name</TH>
    <TH bgColor=3D#808080>Location</TH>
    <TH bgColor=3D#cccccc>Manager</TH></TR>
  <TR>
    <TD align=3Dmiddle bgColor=3D#cccccc>10</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc>Accounting</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD></TR></TBODY></TABLE><BR>
<TABLE width=3D650 align=3Dcenter bgColor=3D#ffcc33 border=3D2 noshade>
  <TBODY>
  <TR>
    <TH bgColor=3D#808080>Department Number</TH>
    <TH bgColor=3D#cccccc>Department Name</TH>
    <TH bgColor=3D#808080>Location</TH>
    <TH bgColor=3D#cccccc>Manager</TH></TR>
  <TR>
    <TD align=3Dmiddle bgColor=3D#cccccc>30</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc>Sales</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD></TR></TBODY></TABLE><BR>
<TABLE width=3D650 align=3Dcenter bgColor=3D#ffcc33 border=3D2 noshade>
  <TBODY>
  <TR>
    <TH bgColor=3D#808080>Department Number</TH>
    <TH bgColor=3D#cccccc>Department Name</TH>
    <TH bgColor=3D#808080>Location</TH>
    <TH bgColor=3D#cccccc>Manager</TH></TR>
  <TR>
    <TD align=3Dmiddle bgColor=3D#cccccc>30</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc>Sales</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD></TR></TBODY></TABLE><BR>
<TABLE width=3D650 align=3Dcenter bgColor=3D#ffcc33 border=3D2 noshade>
  <TBODY>
  <TR>
    <TH bgColor=3D#808080>Department Number</TH>
    <TH bgColor=3D#cccccc>Department Name</TH>
    <TH bgColor=3D#808080>Location</TH>
    <TH bgColor=3D#cccccc>Manager</TH></TR>
  <TR>
    <TD align=3Dmiddle bgColor=3D#cccccc>40</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc>Manufacturing</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD></TR></TBODY></TABLE><BR>
<TABLE width=3D650 align=3Dcenter bgColor=3D#ffcc33 border=3D2 noshade>
  <TBODY>
  <TR>
    <TH bgColor=3D#808080>Department Number</TH>
    <TH bgColor=3D#cccccc>Department Name</TH>
    <TH bgColor=3D#808080>Location</TH>
    <TH bgColor=3D#cccccc>Manager</TH></TR>
  <TR>
    <TD align=3Dmiddle bgColor=3D#cccccc>40</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc>Manufacturing</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD></TR></TBODY></TABLE><BR>
<TABLE width=3D650 align=3Dcenter bgColor=3D#ffcc33 border=3D2 noshade>
  <TBODY>
  <TR>
    <TH bgColor=3D#808080>Department Number</TH>
    <TH bgColor=3D#cccccc>Department Name</TH>
    <TH bgColor=3D#808080>Location</TH>
    <TH bgColor=3D#cccccc>Manager</TH></TR>
  <TR>
    <TD align=3Dmiddle bgColor=3D#cccccc>50</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc>Shipping</TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD>
    <TD align=3Dmiddle bgColor=3D#cccccc></TD></TR></TBODY></TABLE><BR>
</BODY></HTML>
