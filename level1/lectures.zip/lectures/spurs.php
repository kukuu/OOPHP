<?php 
echo "This is the  $premierClub squad for the European Champions League<br />";
echo "
1   Heurelho Gomes <br />
2   Alan Hutton <br />
3   Gareth Bale <br />
4   Younes Kaboul <br />
5   David Bentley <br />
6   Tom Huddlestone <br />
7   Aaron Lennon <br />
8   Jermaine Jenas <br />
9   Roman Pavlyuchenko <br />
10   Robbie Keane <br />
12   Wilson Palacios <br />
14   Luka Modric <br />
15   Peter Crouch <br />
16   Kyle Naughton <br />
17   Dos Santos Giovani <br />
18   Jermain Defoe <br />
19   Sebastien Bassong <br />
20   Michael Dawson <br />
21   Niko Kranjcar <br />
22   Vedran Corluka <br />
23   Carlo Cudicini <br />
24   Jamie O'Hara <br />
25   Danny Rose <br />
26   Ledley King <br />
27   Ben Alnwick <br />
28   Kyle Walker <br />
29   Jake Livermore <br />
32   Benoit Assou-Ekotto <br />
39   Jonathan Woodgate <br />
   Calum Butcher <br />
   William Gallas <br />
   Stipe Pletikosa <br />
   Raniere Sandro <br />
   Adam Smith <br />
   Rafael Van der Vaart <br />
";
?>