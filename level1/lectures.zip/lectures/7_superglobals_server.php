<?php
	foreach ($_SERVER  as $var => $value) {
		echo "$var   :  $value <br />";// Note here => is literal not a syntax as above
}
?>

