

<?php
	$capitals= array ("Paris","London","New York");
	rsort($capitals);
	for($i=0;$i<count($capitals);$i++) {
	echo "$capitals[$i] <br />";	
}
	

?>



