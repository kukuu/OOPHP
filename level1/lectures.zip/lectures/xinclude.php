

<?php

echo "<div>Hi there! We are happy you have chosen this course<strong>(This is a file inclusion statement(include once))</strong></div>";

?>
