<?php
	printf("your IP address is : %s ", $_SERVER['REMOTE_ADDR']);
	//Expects returning data format as string - %s
?>
