
<?php
	define ("PI",3.141592);
	printf("The value of PI is %f",PI);
	$pi2 = 2 * PI;
	//%f=>floating point
	printf("<br />The value of PI double is %f", $pi2 );//Returning a floating point number
?>


