<?php
    $website = "http://www.codeunique.com";
    echo <<<EXCERPT
	<p>Amongst the latest IT consultancy companies in London is  <a href="$website">codeunique.com</a> which is in Hammersmith, West London</p>
EXCERPT;
?>

