<!-- Program Name:  mysqlphp.php
     Description: PHP program that sends an SQL query to the
                  MySQL server and displays the results.
-->
<html>
<head>
<title>Members Only</title>
<style>
.red {
	color:#ff0000;
}

.gold {
	color:#ff9933;
	font-size:2em;
	
	}
.torquoise {
	color:#ff00ff;
	font-weight:bold;
}

.dg {
	color:#ffcc33;
}

th,td {width:120px;}

</style>
</head>
<body>
<form action=<?=$_SERVER['PHP_SELF']?> method="get">
 	<table  align="center" width="100%">
		<tr>
			<td colspan="2">
 				<span class="gold">
						<strong>Hello! Welcome to The MySQL/PHP Course</strong>
				</span>
			</td>
		</tr>
  		<tr>
			<td align="right" valign="top">
				<div class="torquoise" align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Type in SQL query</div>
			</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea name="query" cols="60" rows="10" value=''><?php echo $query ?></textarea></td></tr>
  		<tr>
			<td colspan="2" align="center"><input type="submit" value="Submit Query"></td>
		</tr>
 	</table>
</form>
<?php
echo "<p></p>";

 $user="root";
 $host="localhost";
 $password="";
 /* $password="c00k1e1";*/
 $database = 'mysqlphp';
 $query = $_GET['query'];
 $query = stripSlashes($query) ;
 $query = strip_tags($query) ;
 
 
 

  
if (!mysql_connect($host,$user,$password)) {echo "<p>Unable to connect to database</p>";}
if (!mysql_select_db($database)) {echo "<p><strong>Unable to select database</span></strong>";}
$r = mysql_query($query);
if (!$r) {echo "<p align=center><strong>Unable to query to database</strong></p>";}
else {

//Use nested if conditions to attach functions and call on radio buttons and check boxes. have IDs in the form ements

//for example if name or id="querry" output table
//if name or id  is that of checbox or radio show a  different table form a database
	
	echo "<h4 align=center>$query</h4>";
	echo "<table  width=100% border=2 noshade bgcolor=#ffcc33>";
		echo "<tr><th bgcolor=#cccccc>ID</th>
				<th bgcolor=#808080>Name</th>
				<th bgcolor=#cccccc>Surname</th>
				<th bgcolor=#cccccc>Gender</th>
				<th bgcolor=#808080>Email</th><th bgcolor=#cccccc>Phone</th>
				<th bgcolor=#808080>Mobile</th><th bgcolor=#cccccc>Pet</th></tr>";
		echo "</table>";
	while ($row = mysql_fetch_array($r)) {
	
	
		
		echo "<table cellspacing=2 cellpadding=2  width=100% border=2 noshade bgcolor=#ffcc33>";
			echo "<tr><td bgcolor=#cccccc width=65>".$row['ID']."</td>
				<td bgcolor=#cccccc width=145>".$row['Name']."</td>
				<td bgcolor=#cccccc width=210>".$row['Surname']."</td>
				<td bgcolor=#cccccc width=173>".$row['gender']."</td>
				<td bgcolor=#cccccc width=135>".$row['email']."</td>
				<td bgcolor=#cccccc width=148>".$row['phone']."</td>
				<td bgcolor=#cccccc width=170>".$row['mobile'];
		echo "</td><td bgcolor=#cccccc>";
		echo '<img width="120" height="100" src="/lectures/images/'.$row["pet"].'.jpg">';
		echo "</td></tr>";
echo "</table>";


	}
}
 
?>
</body>
</html>
