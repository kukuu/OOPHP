<?php
	printf("Your browser  is : %s" , $_SERVER['HTTP_USER_AGENT']);
?>
